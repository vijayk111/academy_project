package com.cognizant.academy.dao;
import java.sql.*;

import com.cognizant.academy.dbutil.DBConnection;
import com.cognizant.academy.model.Stack;

public class AddDataDao {
	public void addStudent(Stack s) {
		Connection conn=null;
		PreparedStatement ps=null;
		try {	
			conn=DBConnection.getConnection();
			String q="insert into stack(name) values(?)";
			ps=conn.prepareStatement(q);   		
    		ps.setString(1,s.getName());
    		ps.executeUpdate();    		
    		System.out.println("added");	
        } 
		catch (Exception p) {
        	System.out.println(p);           
        }
	
	}
}
