package com.cognizant.academy.dao;

import java.sql.*;
import java.util.*;
import com.cognizant.academy.model.Stack;

public class FetchAllDao {
	public List<Stack> getStudent() {
	
		
		
		List<Stack> l=new ArrayList<Stack>();

        try {
        	
        	Class.forName("com.mysql.jdbc.Driver");
            Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/Academy", "root","");
            
            Statement p=connect.createStatement();
            ResultSet rs = p.executeQuery("select * from stack");
            
            while(rs.next()) 
            {
            	Stack s1=new Stack();
            		s1.setId(rs.getInt("id"));
            		
            	    s1.setName(rs.getString("name"));
            	     l.add(s1);
            }
            
        } catch (Exception p) {
        	System.out.println(p);
           
        }
	return l;
	}
}
