package com.cognizant.academy.dao;

import java.sql.*;

import com.cognizant.academy.dbutil.DBConnection;

public class EditStackDao {

	public boolean EditStackName(String name, String oname) {
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try{
			conn=DBConnection.getConnection();
			String q="select id from stack where name=?";
			ps=conn.prepareStatement(q);
			ps.setString(1, name);
			rs=ps.executeQuery();
			if(rs.next()){
				
			}
			else{
				String q1="update stack set name=? where name=?";
				ps=conn.prepareStatement(q1);
				ps.setString(1, name);
				ps.setString(2, oname);
				ps.executeQuery();
				System.out.println("updated");
			}
		}catch(Exception e){
			
		}
		
		return false;
	}

}
