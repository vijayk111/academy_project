package com.cognizant.academy.bo;

import com.cognizant.academy.dao.AddDataDao;
import com.cognizant.academy.model.Stack;

public class AddDataBo {

	public void addStudent(Stack s) {
		AddDataDao ad=new AddDataDao();
		ad.addStudent(s);
		

	}

}
