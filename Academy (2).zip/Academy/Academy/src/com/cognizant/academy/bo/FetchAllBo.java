package com.cognizant.academy.bo;
import java.util.List;

import com.cognizant.academy.dao.FetchAllDao;
import com.cognizant.academy.model.Stack;

public class FetchAllBo {

	public List<Stack> fetchStudent() {
		FetchAllDao fd=new FetchAllDao();
		return fd.getStudent();
		

	}

}
