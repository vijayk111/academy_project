package com.cognizant.academy.bo;

import com.cognizant.academy.dao.EditStackDao;

public class EditStackBo {
	public boolean EditStackName(String name, String oname){
		EditStackDao esd=new EditStackDao();
		return esd.EditStackName(name, oname);
	}
}
