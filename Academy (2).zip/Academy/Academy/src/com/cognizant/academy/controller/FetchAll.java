package com.cognizant.academy.controller;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.cognizant.academy.bo.FetchAllBo;
import com.cognizant.academy.model.Stack;

@WebServlet("/FetchAll")
public class FetchAll extends HttpServlet {
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		 service(request, response);
	 }
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	Stack s=new Stack();
    	
    	
    	FetchAllBo fb=new FetchAllBo();
    	
    	PrintWriter out=response.getWriter();
    	List<Stack> l1=fb.fetchStudent();
    	
    		
    	request.setAttribute("List",l1);
    	RequestDispatcher dis=request.getRequestDispatcher("stack.jsp");
    	dis.forward(request, response);
    	
    	
    }
}
