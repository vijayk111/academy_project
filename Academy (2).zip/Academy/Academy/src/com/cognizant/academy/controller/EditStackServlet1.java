package com.cognizant.academy.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.academy.bo.EditStackBo;
import com.cognizant.academy.model.Stack;

public class EditStackServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public EditStackServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Stack s=new Stack();
		RequestDispatcher dis=request.getRequestDispatcher("EditStack.jsp");
		dis.forward(request, response);
		String name=request.getParameter("stackname_update");
		String oname=request.getParameter("name");
		System.out.println(oname);
		//s.setName(name);
		EditStackBo esb=new EditStackBo();
		if(esb.EditStackName(name, oname)){
			dis=request.getRequestDispatcher("Stack.jsp");
			dis.forward(request, response);
		}else{
			dis=request.getRequestDispatcher("EditStack.jsp");
			dis.forward(request, response);
		}
	}

}
