package com.cognizant.academy.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.academy.bo.AddDataBo;
import com.cognizant.academy.model.Stack;


@WebServlet("/AddData")
public class AddData extends HttpServlet {
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Stack s=new Stack();
    	
    	s.name=request.getParameter("name");
    	AddDataBo adb=new AddDataBo();	
    	adb.addStudent(s);	
    	
    	RequestDispatcher rd=request.getRequestDispatcher("FetchAll");
    	rd.forward(request, response);
    				
    	System.out.println("added"); 
    	
	}

}
